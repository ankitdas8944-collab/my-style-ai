import "dotenv/config";
import express from "express";
import multer from "multer";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { files: 4, fileSize: 8 * 1024 * 1024 }
});

const PORT = Number(process.env.PORT || 3000);
const MODEL = process.env.OPENAI_MODEL || "gpt-5.6-luna";

if (!process.env.OPENAI_API_KEY) {
  console.warn("WARNING: OPENAI_API_KEY is not set. /api/analyze will not work until it is configured.");
}

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(express.static(__dirname));

function toDataUrl(file) {
  const mime = file.mimetype || "image/jpeg";
  return `data:${mime};base64,${file.buffer.toString("base64")}`;
}

const schema = {
  type: "object",
  additionalProperties: false,
  properties: {
    status: { type: "string", enum: ["ok", "no_reliable_result"] },
    bestPair: {
      anyOf: [
        {
          type: "object",
          additionalProperties: false,
          properties: {
            top: { type: "integer" },
            bottom: { type: "integer" }
          },
          required: ["top", "bottom"]
        },
        { type: "null" }
      ]
    },
    pairs: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          top: { type: "integer" },
          bottom: { type: "integer" },
          valid: { type: "boolean" },
          reason: { type: "string" }
        },
        required: ["top", "bottom", "valid", "reason"]
      }
    }
  },
  required: ["status", "bestPair", "pairs"]
};

function buildInput(tops, bottoms) {
  const content = [{
    type: "input_text",
    text: `
You are a careful personal styling assistant.

The user uploaded separate TOP/SHIRT images and BOTTOM/PANT images.
Your job is ONLY to decide which available shirt + pant combination is the best visual outfit.

Important rules:
1. A single shirt/top is valid. A single pant/jeans/trouser is valid. The user does NOT need to upload a person wearing the outfit.
2. First inspect whether each uploaded image actually contains clothing of the requested category.
3. If an image is clearly not clothing, mark every pair using that image as valid=false.
4. Compare EVERY possible valid top × bottom pair. Do not compare only the first pair.
5. Consider visible colour harmony, undertone, contrast, pattern interaction, silhouette/style compatibility, occasion neutrality, and overall coordination.
6. Do NOT judge the person's body, attractiveness, skin tone, or physical appearance.
7. Pick a best pair ONLY when there is enough visual evidence. If the images are too unclear, or there is no valid pair, return status=no_reliable_result and bestPair=null.
8. Never invent an answer, never use a random choice, and never output a numeric percentage.
9. Give a short, concrete reason for each pair that is valid.
10. The top and bottom indexes are zero-based and correspond to the order of images below.

TOPS:
${tops.map((_,i)=>`TOP_${i+1}`).join(", ")}

BOTTOMS:
${bottoms.map((_,i)=>`BOTTOM_${i+1}`).join(", ")}

Return ONLY the required JSON schema.
`
  }];

  for (let i = 0; i < tops.length; i++) {
    content.push({
      type: "input_text",
      text: `This next image is TOP_${i + 1}. Analyze it as a shirt/top candidate.`
    });
    content.push({
      type: "input_image",
      image_url: toDataUrl(tops[i]),
      detail: "high"
    });
  }

  for (let i = 0; i < bottoms.length; i++) {
    content.push({
      type: "input_text",
      text: `This next image is BOTTOM_${i + 1}. Analyze it as a pant/jeans/bottom candidate.`
    });
    content.push({
      type: "input_image",
      image_url: toDataUrl(bottoms[i]),
      detail: "high"
    });
  }

  return [{
    role: "user",
    content
  }];
}

app.post("/api/analyze", upload.fields([
  { name: "tops", maxCount: 2 },
  { name: "bottoms", maxCount: 2 }
]), async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "OPENAI_API_KEY is not configured on the server." });
    }

    const tops = req.files?.tops || [];
    const bottoms = req.files?.bottoms || [];

    if (!tops.length || !bottoms.length) {
      return res.status(400).json({ error: "Upload at least one top and one bottom." });
    }

    const response = await client.responses.create({
      model: MODEL,
      store: false,
      input: buildInput(tops, bottoms),
      text: {
        format: {
          type: "json_schema",
          name: "outfit_pair_result",
          strict: true,
          schema
        }
      }
    });

    let data;
    try {
      data = JSON.parse(response.output_text);
    } catch {
      return res.status(502).json({ error: "The AI returned an invalid structured result." });
    }

    // Server-side verification: reject malformed or out-of-range winners.
    if (!Array.isArray(data.pairs) || !("bestPair" in data)) {
      return res.status(502).json({ error: "The AI result failed server validation." });
    }

    if (data.bestPair !== null) {
      const { top, bottom } = data.bestPair;
      const validPair = data.pairs.find(
        p => p.top === top && p.bottom === bottom && p.valid === true
      );
      if (!validPair ||
          top < 0 || top >= tops.length ||
          bottom < 0 || bottom >= bottoms.length) {
        data.status = "no_reliable_result";
        data.bestPair = null;
      }
    }

    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Vision AI request failed. No recommendation was generated." });
  }
});

app.listen(PORT, "127.0.0.1", () => {
  console.log(`My Style is running at http://127.0.0.1:${PORT}`);
});
