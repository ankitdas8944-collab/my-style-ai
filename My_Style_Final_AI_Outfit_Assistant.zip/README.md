# My Style — Final AI Outfit Assistant

## What this version does
- Premium animated mobile UI
- Password: `ANKRIJA`
- Special Srija welcome message
- Upload up to 2 tops/shirts and 2 bottoms/jeans
- Sends the actual images to a secure server-side Vision AI request
- Compares every available Top × Bottom pair
- Rejects non-clothing images
- Does not use random/fake percentages
- Does not invent a winner if the AI cannot reliably decide
- Does not put the API key in the browser

## Setup
1. Install a current Node.js version.
2. Open a terminal in this folder.
3. Run:
   `npm install`
4. Copy `.env.example` to `.env`.
5. Put your OpenAI API key in `.env`:
   `OPENAI_API_KEY=...`
6. Run:
   `npm start`
7. Open `http://127.0.0.1:3000`

The OpenAI API key must stay on the server. OpenAI's current documentation recommends server-side SDK usage and environment-variable storage for API keys. The Responses API supports image inputs and structured JSON output. 

## Important
The recommendation is an AI styling opinion, not an objective guarantee. The app is deliberately fail-safe: if the model cannot verify a best pair, it returns no recommendation instead of fabricating one.
